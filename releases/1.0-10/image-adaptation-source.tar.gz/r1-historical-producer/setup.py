#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Install the Kernarium virtual-device policy into an Ubuntu Touch root."""
from __future__ import annotations

import argparse
from pathlib import Path


def write(root: Path, name: str, text: str, mode: int = 0o644) -> None:
    target = root / name
    # Never follow an image's absolute symlink into the build host.
    parent = root
    for part in Path(name).parts[:-1]:
        parent /= part
        if parent.is_symlink():
            raise ValueError(f"policy directory is a symlink: {parent}")
        parent.mkdir(exist_ok=True)
    if target.is_symlink():
        target.unlink()
    target.write_text(text)
    target.chmod(mode)


def mask(root: Path, unit: str) -> None:
    target = root / "etc/systemd/system" / unit
    if target.exists() or target.is_symlink():
        target.unlink()
    target.symlink_to("/dev/null")


def apply(root: Path) -> None:
    if root == Path("/"):
        raise ValueError("refusing the build host's root filesystem")
    release = (root / "etc/os-release").read_text()
    if "VARIANT_ID=touch" not in release:
        raise ValueError("source is not an Ubuntu Touch root filesystem")
    for path in ("usr/bin/lomiri", "usr/sbin/ubuntu-touch-lightdm-session",
                 "usr/lib/aarch64-linux-gnu/mir1/server-platform/graphics-mesa-kms.so.16"):
        if not (root / path).is_file():
            raise ValueError(f"Ubuntu Touch PDK component is missing: {path}")

    # The boot ramdisk mounts the selected root. The source's EFI and boot
    # partitions and UUIDs do not exist in the virtual-device guest.
    write(root, "etc/fstab", "# Root is mounted by the Kernarium boot ramdisk.\n")
    mask(root, "ubports-pdk-mount.service")
    for unit in ("getty@tty0.service", "getty@tty1.service"):
        mask(root, unit)
    write(root, "etc/machine-id", "")
    machine_id = root / "var/lib/dbus/machine-id"
    if machine_id.exists() or machine_id.is_symlink():
        machine_id.unlink()
    machine_id.symlink_to("../../../etc/machine-id")
    write(root, "etc/hostname", "toucharium\n")

    # phablet is an extrausers account in Ubuntu Touch, not an /etc/passwd
    # account. Preserve it and extend the existing device groups directly.
    groups = (root / "etc/group").read_text().splitlines()
    for index, line in enumerate(groups):
        fields = line.split(":")
        if len(fields) == 4 and fields[0] in {"video", "render", "input"}:
            members = fields[3].split(",") if fields[3] else []
            if "phablet" not in members:
                members.append("phablet")
            fields[3] = ",".join(members)
            groups[index] = ":".join(fields)
    write(root, "etc/group", "\n".join(groups) + "\n")
    write(root, "etc/udev/rules.d/70-toucharium-virtual-devices.rules", '''# SPDX-License-Identifier: GPL-2.0-or-later
SUBSYSTEM=="drm", KERNEL=="card[0-9]*", GROUP="video", MODE="0660", TAG+="uaccess", TAG+="seat"
SUBSYSTEM=="drm", KERNEL=="renderD[0-9]*", GROUP="render", MODE="0660", TAG+="uaccess"
SUBSYSTEM=="input", KERNEL=="event[0-9]*", GROUP="input", MODE="0660", TAG+="uaccess"
''')
    # Keep the PDK's Ubuntu Touch LightDM -> system compositor -> Lomiri
    # session. Mir's KMS probe needs the same override as on QEMU/KVM.
    write(root, "etc/default/lsc-wrapper.d/90-toucharium.conf", '''# SPDX-License-Identifier: GPL-2.0-or-later
export MIR_MESA_KMS_DISABLE_MODESET_PROBE=1
''')
    write(root, "etc/NetworkManager/system-connections/toucharium.nmconnection", '''# SPDX-License-Identifier: GPL-2.0-or-later
[connection]
id=Toucharium Ethernet
type=ethernet
autoconnect=true
[ethernet]
[ipv4]
method=auto
[ipv6]
method=auto
''', 0o600)
    write(root, "etc/toucharium-release", "SOURCE=ubuntu-touch-24.04-1.x-pdk-470-arm64\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    options = parser.parse_args()
    apply(options.root.resolve())


if __name__ == "__main__":
    main()

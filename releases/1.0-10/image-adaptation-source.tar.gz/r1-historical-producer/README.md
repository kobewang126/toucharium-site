# Ubuntu Touch guest image

This producer adapts the pinned official UBports arm64 PDK image for the
Kernarium virtual devices. It preserves Ubuntu Touch's Lomiri, LightDM system
compositor session, extrausers account and application services. The policy
removes PDK-specific host mounts and boot-partition UUIDs and grants the
phablet session access to the virtual graphics and input devices.

`sources.json` pins the official archive and raw disk. On Linux, decompress the
archive and run the producer as root with erofs-utils installed:

```sh
xz -dk ubuntu-touch-pdk-img-arm64.raw.xz
sudo python3 tools/rootfs/ubuntu-touch/derive.py \
  --disk ubuntu-touch-pdk-img-arm64.raw \
  --output /path/to/ubuntu-touch-pdk-470-r1.erofs \
  --work-root /path/to/linux-work
```

The input remains read-only. The producer verifies its size and digest, applies
the policy through overlayfs, checks the EROFS output and writes a receipt beside
it. Existing outputs are refused. The generic boot ramdisk mounts the image and
starts its own `/sbin/init`; the application's successful installation alone
does not prove that the Ubuntu Touch session has booted.

Upstream sources: [UBports PDK](https://github.com/ubports/ubports-pdk) and the
[pinned rootfs build](https://ci.ubports.com/job/ubuntu-touch-rootfs/job/ubports%252F24.04-1.x/470/).
